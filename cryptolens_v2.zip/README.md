# 🚀 CryptoLens v2
CryptoLens — Dashboard harga, chart, & berita kripto real-time (CoinGecko + NewsAPI).

### 📂 Struktur
```
cryptolens/
├── index.html
├── terms.html
├── netlify/functions/
│   ├── coingecko.js
│   └── newsapi.js
└── assets/
```

### ⚙️ Deploy ke Netlify
1. Hubungkan ke GitHub repository.
2. Pengaturan:
   - Publish directory: `/`
   - Functions directory: `netlify/functions`
3. Tambahkan Environment Variable:
   - `NEWSAPI_KEY` = (API key dari newsapi.org)
4. Deploy!

### 🧠 Disclaimer
Informasi hanya untuk riset. Tidak memberi saran keuangan.
